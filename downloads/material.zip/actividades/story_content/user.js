function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6A1Shxnyd7Z":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

